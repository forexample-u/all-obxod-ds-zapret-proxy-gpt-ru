@echo off
setlocal enabledelayedexpansion

>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting Admin rights...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
    pushd "%CD%"
    CD /D "%~dp0"

set "hosts_file=%SystemRoot%\System32\drivers\etc\hosts"
set "IP=45.155.204.190"
set "temp_file=%TEMP%\hosts_clean.tmp"

set "DOMAINS=api.spotify.com login5.spotify.com encore.scdn.co gew1-spclient.spotify.com spclient.wg.spotify.com api-partner.spotify.com aet.spotify.com www.spotify.com accounts.spotify.com open.spotify.com  accounts.scdn.co gew1-dealer.spotify.com open-exp.spotifycdn.com www-growth.scdn.co gemini.google.com aistudio.google.com"

echo.
echo [1/4] Creating backup...
copy /y "%hosts_file%" "%hosts_file%.bak.%RANDOM%" >nul
echo       Backup saved.

echo.
echo [2/4] Cleaning old entries...
type "%hosts_file%" > "%temp_file%"
for %%D in (%DOMAINS%) do (
    type "%temp_file%" | findstr /v /i "%%D" > "%temp_file%.2"
    move /y "%temp_file%.2" "%temp_file%" >nul
)

echo.
echo [3/4] Writing new IP (%IP%)...
echo. >> "%temp_file%"
for %%D in (%DOMAINS%) do (
    echo %IP% %%D >> "%temp_file%"
)

copy /y "%temp_file%" "%hosts_file%" >nul
del "%temp_file%"

echo.
echo [4/4] Flushing DNS cache...
ipconfig /flushdns >nul

















set "hosts_file=%SystemRoot%\System32\drivers\etc\hosts"
set "IP=80.74.29.235"
set "temp_file=%TEMP%\hosts_clean.tmp"

set "DOMAINS=elevenlabs.io chatgpt.com ab.chatgpt.com auth.openai.com auth0.openai.com platform.openai.com cdn.oaistatic.com files.oaiusercontent.com cdn.auth0.com tcr9i.chat.openai.com webrtc.chatgpt.com aistudio.google.com generativelanguage.googleapis.com alkalimakersuite-pa.clients6.google.com copilot.microsoft.com sydney.bing.com edgeservices.bing.com claude.ai aitestkitchen.withgoogle.com aisandbox-pa.googleapis.com x.ai grok.com accounts.x.ai labs.google anthropic.com api.anthropic.com api.openai.com"

echo.
echo [1/4] Creating backup...
copy /y "%hosts_file%" "%hosts_file%.bak.%RANDOM%" >nul
echo       Backup saved.

echo.
echo [2/4] Cleaning old entries...
type "%hosts_file%" > "%temp_file%"
for %%D in (%DOMAINS%) do (
    type "%temp_file%" | findstr /v /i "%%D" > "%temp_file%.2"
    move /y "%temp_file%.2" "%temp_file%" >nul
)

echo.
echo [3/4] Writing new IP (%IP%)...
echo. >> "%temp_file%"
for %%D in (%DOMAINS%) do (
    echo %IP% %%D >> "%temp_file%"
)

copy /y "%temp_file%" "%hosts_file%" >nul
del "%temp_file%"

echo.
echo [4/4] Flushing DNS cache...
ipconfig /flushdns >nul






