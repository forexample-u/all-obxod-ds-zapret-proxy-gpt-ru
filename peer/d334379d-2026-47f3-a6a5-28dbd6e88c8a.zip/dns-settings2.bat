set "hosts_file=%SystemRoot%\System32\drivers\etc\hosts"
set "IP=31.13.86.174"
set "temp_file=%TEMP%\hosts_clean.tmp"
set "DOMAINS=instagram.com www.instagram.com"
copy /y "%hosts_file%" "%hosts_file%.bak.%RANDOM%" >nul
type "%hosts_file%" > "%temp_file%"
for %%D in (%DOMAINS%) do (
    type "%temp_file%" | findstr /v /i "%%D" > "%temp_file%.2"
    move /y "%temp_file%.2" "%temp_file%" >nul
)
echo. >> "%temp_file%"
for %%D in (%DOMAINS%) do (
    echo %IP% %%D >> "%temp_file%"
)
copy /y "%temp_file%" "%hosts_file%" >nul
del "%temp_file%"
ipconfig /flushdns >nul




set "hosts_file=%SystemRoot%\System32\drivers\etc\hosts"
set "IP=31.13.86.9"
set "temp_file=%TEMP%\hosts_clean.tmp"
set "DOMAINS=gateway.instagram.com"
copy /y "%hosts_file%" "%hosts_file%.bak.%RANDOM%" >nul
type "%hosts_file%" > "%temp_file%"
for %%D in (%DOMAINS%) do (
    type "%temp_file%" | findstr /v /i "%%D" > "%temp_file%.2"
    move /y "%temp_file%.2" "%temp_file%" >nul
)
echo. >> "%temp_file%"
for %%D in (%DOMAINS%) do (
    echo %IP% %%D >> "%temp_file%"
)
copy /y "%temp_file%" "%hosts_file%" >nul
del "%temp_file%"
ipconfig /flushdns >nul




set "hosts_file=%SystemRoot%\System32\drivers\etc\hosts"
set "IP=31.13.86.52"
set "temp_file=%TEMP%\hosts_clean.tmp"
set "DOMAINS=edge-chat.instagram.com scontent.cdninstagram.com static.cdninstagram.com cdninstagram.com graph.instagram.com i.instagram.com fbcdn.net"
copy /y "%hosts_file%" "%hosts_file%.bak.%RANDOM%" >nul
type "%hosts_file%" > "%temp_file%"
for %%D in (%DOMAINS%) do (
    type "%temp_file%" | findstr /v /i "%%D" > "%temp_file%.2"
    move /y "%temp_file%.2" "%temp_file%" >nul
)
echo. >> "%temp_file%"
for %%D in (%DOMAINS%) do (
    echo %IP% %%D >> "%temp_file%"
)
copy /y "%temp_file%" "%hosts_file%" >nul
del "%temp_file%"
ipconfig /flushdns >nul




set "hosts_file=%SystemRoot%\System32\drivers\etc\hosts"
set "IP=157.240.205.63"
set "temp_file=%TEMP%\hosts_clean.tmp"
set "DOMAINS=scontent-hel3-1.cdninstagram.com scontent-hel13-1.cdninstagram.com"
copy /y "%hosts_file%" "%hosts_file%.bak.%RANDOM%" >nul
type "%hosts_file%" > "%temp_file%"
for %%D in (%DOMAINS%) do (
    type "%temp_file%" | findstr /v /i "%%D" > "%temp_file%.2"
    move /y "%temp_file%.2" "%temp_file%" >nul
)
echo. >> "%temp_file%"
for %%D in (%DOMAINS%) do (
    echo %IP% %%D >> "%temp_file%"
)
copy /y "%temp_file%" "%hosts_file%" >nul
del "%temp_file%"
ipconfig /flushdns >nul